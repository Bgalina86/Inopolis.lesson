package Homework7;

import java.time.LocalDateTime;

public interface HumanReadableTimestamp {

    String getTimestamp(LocalDateTime eventTimestamp);
}
