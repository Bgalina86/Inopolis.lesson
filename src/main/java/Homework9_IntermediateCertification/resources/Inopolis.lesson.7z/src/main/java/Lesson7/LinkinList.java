package Lesson7;

import java.util.LinkedList;
import java.util.List;

public class LinkinList {

    public static void main(String[] args) {
        List<String>strings=new LinkedList<>();

        strings.add("Nikita");
        strings.add("Женя");
        strings.add("Камиль");
        strings.add("Галина");
        strings.add("Игорь");

    }

}
