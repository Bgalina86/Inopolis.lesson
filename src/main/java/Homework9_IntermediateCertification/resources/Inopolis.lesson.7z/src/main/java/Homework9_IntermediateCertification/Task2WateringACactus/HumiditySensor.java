package Homework9_IntermediateCertification.Task2WateringACactus;

public interface HumiditySensor {

    int getHumiditySensor();

    int makeHumiditySensor(int humiditySensor);
}
