package Lesson5;

import java.util.Scanner;

public class MethodDemo {

    public static void main(String[] args) {
        String  name ="Alex";
        int x=10;
        Scanner sc = new Scanner(System.in);

    }

}
