package Lesson8;

import java.time.LocalTime;
import java.util.Scanner;

public class Alarm {


    public static void main(String[] args) {
        System.out.println("");
        String input = new Scanner(System.in).nextLine();

        LocalTime parse = LocalTime.now();
    }}
