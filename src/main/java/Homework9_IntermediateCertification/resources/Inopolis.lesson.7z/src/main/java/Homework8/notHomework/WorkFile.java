package Homework8.notHomework;

public interface WorkFile {
// общий интерфейс для обработки файлов любого типа

}
