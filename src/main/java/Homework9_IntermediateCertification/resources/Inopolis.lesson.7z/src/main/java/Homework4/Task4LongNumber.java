package Homework4;

// Задание про циклы
//     напечатайте на экран числа от 1 до 1 000 000 000

public class Task4LongNumber {

    public static void main(String[] args) {
        //Организация цикла с i=1 до i = 1000000000
        for (int i = 1; i < 1000000000; i = i + 1) {
            //Вывод на экран
            System.out.println(i);
        }
    }
}
