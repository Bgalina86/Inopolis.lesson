package Lesson8;

public class Date {
    int day;//28,29,30,31
    int month;//12
    int year;//


}
