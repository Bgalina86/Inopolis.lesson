package Homework9_IntermediateCertification.Task2WateringACactus;

import java.time.LocalDate;

public interface WateringPlan {

    LocalDate waterPlants(LocalDate lastWaterDate);
}
