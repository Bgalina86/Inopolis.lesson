package Lessons6;

public class Playgroud {

    public static void main(String[] args) {
        User u1= new User("Alex","alex@mail.ru");
        u1.notifyEmail("Вас хотя добавить в друзья");
    }

}
