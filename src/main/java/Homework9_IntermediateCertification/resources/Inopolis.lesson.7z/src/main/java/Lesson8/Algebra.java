package Lesson8;

public class Algebra {

    public static void main(String[] args) {

    }

}
