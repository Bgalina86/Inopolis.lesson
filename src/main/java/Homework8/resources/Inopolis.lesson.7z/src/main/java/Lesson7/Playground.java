package Lesson7;

public class Playground {

    public static void main(String[] args) {
        String[] strings = new String[4];

        strings[0] ="1";
        strings[0] ="22";
        strings[0] ="333";
        strings[0] ="4444";

for (String string :strings) {
    if (strings != null) {
        System.out.println(string.length());
    }
}}
}
