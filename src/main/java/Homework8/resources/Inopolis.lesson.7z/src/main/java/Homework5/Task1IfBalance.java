package Homework5;

//●	Создайте переменную balance типа int.
//    ●	Положите в нее значение
//    ●	Если значение переменной равно 10, напишите "Десятка"

public class Task1IfBalance {

    public static void main(String[] args) {
        int balance;
        balance = 10;
        if (balance == 10) {
            System.out.println("Десятка");
        }
    }
}
