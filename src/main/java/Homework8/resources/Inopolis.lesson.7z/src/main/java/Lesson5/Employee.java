package Lesson5;

public class Employee {
    String name;


}
