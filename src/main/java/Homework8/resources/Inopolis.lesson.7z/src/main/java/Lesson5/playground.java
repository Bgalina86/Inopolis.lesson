package Lesson5;

public class playground {

    public static void main(String[] args) {

        String user = "Alex";
        String status = "gruynd";

        if (status.equals("gruynd")) {
            System.out.println("Круто");
        } else {
            System.out.println("не круто");
        }
    }
}

