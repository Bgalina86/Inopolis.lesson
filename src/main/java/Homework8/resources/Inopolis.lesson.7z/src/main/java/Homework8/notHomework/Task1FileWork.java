package Homework8.notHomework;

public class Task1FileWork {

}
