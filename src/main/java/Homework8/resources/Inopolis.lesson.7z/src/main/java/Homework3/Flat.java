package Homework3;

public class Flat {

    String NumberOfRooms; // кол-во комнат
    String Floor; // этаж
    String Repair; //тип ремонта
    boolean Elevator; // лифт
    double Price; // цена

    public Flat(String myNumberOfRooms, String myFloor, String myRepair, boolean myElevator, double myPrice) {
        NumberOfRooms = myNumberOfRooms;
        Floor = myFloor;
        Repair = myRepair;
        Elevator = myElevator;
        Price = myPrice;



    }

}
