package Lesson4;

public class ArrayArray {

    public static void main(String[] args) {
        int[][] table = new int[2][3];

    }

}
