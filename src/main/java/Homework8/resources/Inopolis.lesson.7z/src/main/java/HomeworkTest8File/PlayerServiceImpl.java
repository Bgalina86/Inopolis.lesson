package HomeworkTest8File;

public class PlayerServiceImpl  {

//    private List<String> storage;
//    private DataHelper dataHelper;
//
//    public PlayerServiceImpl(PlayerService dh) {
//        this.dataHelper = dh;
//        this.storage = dataHelper.load();
//    }
//
//    @Override
//    public Homework8.Player getPlayerById(int id) throws IOException, JAXBException {
//        return null;
//    }
//
//    @Override
//    public List<Homework8.Player> getPlayers() throws IOException {
//        return null;
//    }
//
//    @Override
//    public int createPlayer(String nickname) throws IOException {
//        return 0;
//    }
//
//    @Override
//    public void writePlayersToFile(List<Homework8.Player> players) throws IOException, JAXBException {
//
//    }
//
//    @Override
//    public List<Homework8.Player> readPlayersFromFile() throws IOException, JAXBException {
//        return null;
//    }
//
//    @Override
//    public Homework8.Player deletePlayer(int id) throws IOException, JAXBException {
//        return null;
//    }
//
//    @Override
//    public int addPoints(int playerId, int points) {
//
//        dataHelper.save(storage);
//        return 0;
//    }
//
//    @Override
//    public List<Homework8.Player> printPlayersFromFile(List<Player> playersToPrint)
//        throws IOException, JAXBException {
//        return null;
//    }
//
//    @Override
//    public int addPlayer(String name) {
//        dataHelper.save(storage);
//        return 0;
//    }
//
//    @Override
//    public String removePlayer(int id) {
//        dataHelper.save(storage);
//        return null;
//    }
//
//    @Override
//    public List<String> getLeaderBoard() {
//        return null;
//    }
}
