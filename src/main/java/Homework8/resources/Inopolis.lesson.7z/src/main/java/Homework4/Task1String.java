package Homework4;

/* Задача про массив строк
 1. Создайте массив
 2. Массив хранит 5 строк.
 3. Массив должен называться todoList
 4. Положите в массив 5 дел на день
 */
public class Task1String {

    public static void main(String[] args) {

        // Организация массива из 5 элементов
        String[] todoList = new String[5];

        //Заполнение массива данными
        todoList[0] = "Заправить кровать ";
        todoList[1] = "Сделать зарядку";
        todoList[2] = "Умыться";
        todoList[3] = "Приготовить завтрак";
        todoList[4] = "Позавтракать";
    }
}
