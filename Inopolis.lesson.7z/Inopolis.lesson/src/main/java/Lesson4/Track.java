package Lesson4;

public class Track {
    int duration;
    String author;
    String title;
    int year;
    byte[] data;

    public Track(int duration, String author, String title, int year, byte[] data){
        this.duration = duration;
        this.author = author;
        this.title = title;
        this.year = year;
        this.data = data;

    }


}
