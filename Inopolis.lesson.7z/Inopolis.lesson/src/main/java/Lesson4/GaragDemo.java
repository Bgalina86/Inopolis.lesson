package Lesson4;

public class GaragDemo {

    public static void main(String[] args) {
        Car mySuper = new Car();
        Car[] garage = new Car[5];

    }

}
