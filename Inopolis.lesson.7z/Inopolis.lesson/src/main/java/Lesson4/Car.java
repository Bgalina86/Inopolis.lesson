package Lesson4;

public class Car {

    public Car() {
        String brend;
        String modek;
        String plateNumber;
        String color;

    }
}
