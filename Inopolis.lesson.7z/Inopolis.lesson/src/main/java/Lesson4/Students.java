package Lesson4;

import java.util.SplittableRandom;

public class Students {
    String Firstname;
    String lastname;
    Boolean strfg;

    public Students(String Firstname, String lastname) {
        this.Firstname = Firstname;
        this.lastname = lastname;
    }
}
