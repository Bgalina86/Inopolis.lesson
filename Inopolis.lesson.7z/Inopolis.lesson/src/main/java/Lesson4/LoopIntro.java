package Lesson4;

public class LoopIntro {

    public static void main(String[] args) {
       System.out.println("Старт");
        int random;
        for (int counter = 0; counter<10;++counter){// counter = counter + 1
            System.out.println("counter = " + counter);
    }
        System.out.println("Финиш");
    }
}
