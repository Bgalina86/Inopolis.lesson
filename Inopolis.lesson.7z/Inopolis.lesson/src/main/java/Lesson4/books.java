package Lesson4;

public class books {

    public static void main(String[] args) {
        String [] books = new String[3];

        books[0] = "12";
        books[1] = "Золотой";
        books[2]="Одноэтажны";
        books[0]="Одноэтажны";

    }

}
