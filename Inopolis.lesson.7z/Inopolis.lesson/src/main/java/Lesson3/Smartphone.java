package Lesson3;

public class Smartphone {
    String brend;
    String model;
    double screen;
    String resolutionH;
    String resolutionW;
    String color;
    int price;
    int ramGb;
    int hddGb = 128;

}
