package Lesson3;

public class Car {
    String brand;
    String model;
    double engineV;
    int year;
    int price;
    public Car(){

    }
}
