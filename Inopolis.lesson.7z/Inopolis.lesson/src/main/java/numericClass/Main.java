package numericClass;

public class Main {
    public static void main(String[] args) {

        var a = 200; //camelCase одно слово и каждое с заглавной
        var b = 300;
        System.out.println(a+b);
        System.out.println( a % b );
        System.out.println( a * b );
        System.out.println( a > b );
    }
}