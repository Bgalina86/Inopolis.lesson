package Homework4;

/* Задача про массив строк
 1. Создайте массив
 2. Массив хранит 5 строк.
 3. Массив должен называться todoList
 4. Положите в массив 5 дел на день
 */
public class Task1String {

    public static void main(String[] args) {

        // Организация массива из 5 элементов
        String[] ArrayOfStrings = new String[5];

        //Заполнение массива данными
        ArrayOfStrings[0] = "Дуб";
        ArrayOfStrings[1] = "Осина";
        ArrayOfStrings[2] = "Ольха";
        ArrayOfStrings[3] = "Черёмуха";
        ArrayOfStrings[4] = "Берёза";
    }

}
